/*
 * Licensed under the LGPL v2.1, see the file COPYING.LIB in this tarball.
 */
#define __WORDSIZE	64
