/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
/* <DESC>
 * multi socket interface with libevent 2
 * </DESC>
 */
/* Example application source code using the multi socket interface to
 * download many files at once.
 *
 * Written by Jeff Pohlmeyer
 *
 * Requires libevent version 2 and a (POSIX?) system that has mkfifo().
 *
 * This is an adaptation of libcurl's "hipev.c" and libevent's "event-test.c"
 * sample programs.
 *
 * When running, the program creates the named pipe "hiper.fifo"
 *
 * Whenever there is input into the fifo, the program reads the input as a list
 * of URL's and creates some new easy handles to fetch each URL via the
 * curl_multi "hiper" API.
 *
 * Thus, you can try a single URL:
 *   % echo http://www.yahoo.com > hiper.fifo
 *
 * Or a whole bunch of them:
 *   % cat my-url-list > hiper.fifo
 *
 * The fifo buffer is handled almost instantly, so you can even add more URL's
 * while the previous requests are still being downloaded.
 *
 * Note:
 *   For the sake of simplicity, URL length is limited to 1023 chars.
 *
 * This is purely a demo app, all retrieved data is discarded by
 * the write callback.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/cdefs.h>
#include <sys/poll.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include <curl/curl.h>

#include <event2/event.h>
#include <event2/event_struct.h>

#define MSG_OUT stdout /* Send info to stdout, change to stderr if you want */

/* Global information, common to all connections */
struct GlobalInfo {
  struct event_base *evbase;
  struct event fifo_event;
  struct event timer_event;
  CURLM *multi;
  int still_running;
  FILE *input;
  int stopped;
};

/* Information associated with a specific easy handle */
struct ConnInfo {
  CURL *curl;
  char *url;
  struct GlobalInfo *global;
  char error[CURL_ERROR_SIZE];
};

/* Information associated with a specific socket */
struct SockInfo {
  curl_socket_t sockfd;
  CURL *curl;
  int action;
  long timeout;
  struct event ev;
  struct GlobalInfo *global;
};

/* Die if we get a bad CURLMcode somewhere */
static void mcode_or_die(const char *where, CURLMcode code)
{
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      fprintf(MSG_OUT, "ERROR: %s returns %s\n", where, s);
      /* ignore this error */
      return;
    }
    fprintf(MSG_OUT, "ERROR: %s returns %s\n", where, s);
    exit(code);
  }
}

/* Update the event timer after curl_multi library calls */
static int multi_timer_cb(CURLM *multi, long timeout_ms, struct GlobalInfo *g)
{
  struct timeval timeout;
  (void)multi;

  timeout.tv_sec = timeout_ms / 1000;
  timeout.tv_usec = (timeout_ms % 1000) * 1000;
  fprintf(MSG_OUT, "multi_timer_cb: Setting timeout to %ld ms\n", timeout_ms);

  /*
   * if timeout_ms is -1, delete the timer
   *
   * For all other values of timeout_ms, this should set or *update* the timer
   * to the new value
   */
  if(timeout_ms == -1)
    evtimer_del(&g->timer_event);
  else /* includes timeout zero */
    evtimer_add(&g->timer_event, &timeout);
  return 0;
}

/* Check for completed transfers, and remove their easy handles */
static void check_multi_info(struct GlobalInfo *g)
{
  char *eff_url;
  CURLMsg *msg;
  int msgs_left;
  struct ConnInfo *conn;

  fprintf(MSG_OUT, "REMAINING: %d\n", g->still_running);
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      CURL *curl = msg->easy_handle;
      CURLcode result = msg->data.result;
      curl_easy_getinfo(curl, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &eff_url);
      fprintf(MSG_OUT, "DONE: %s => (%d) %s\n", eff_url, result, conn->error);
      curl_multi_remove_handle(g->multi, curl);
      free(conn->url);
      curl_easy_cleanup(curl);
      free(conn);
    }
  }
  if(g->still_running == 0 && g->stopped)
    event_base_loopbreak(g->evbase);
}

/* Called by libevent when we get action on a multi socket */
static void event_cb(int fd, short kind, void *userp)
{
  struct GlobalInfo *g = (struct GlobalInfo *)userp;
  CURLMcode mresult;

  int action = ((kind & EV_READ) ? CURL_CSELECT_IN : 0) |
               ((kind & EV_WRITE) ? CURL_CSELECT_OUT : 0);

  mresult = curl_multi_socket_action(g->multi, fd, action, &g->still_running);
  mcode_or_die("event_cb: curl_multi_socket_action", mresult);

  check_multi_info(g);
  if(g->still_running <= 0) {
    fprintf(MSG_OUT, "last transfer done, kill timeout\n");
    if(evtimer_pending(&g->timer_event, NULL)) {
      evtimer_del(&g->timer_event);
    }
  }
}

/* Called by libevent when our timeout expires */
static void timer_cb(int fd, short kind, void *userp)
{
  struct GlobalInfo *g = (struct GlobalInfo *)userp;
  CURLMcode mresult;
  (void)fd;
  (void)kind;

  mresult = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0,
                                     &g->still_running);
  mcode_or_die("timer_cb: curl_multi_socket_action", mresult);
  check_multi_info(g);
}

/* Clean up the SockInfo structure */
static void remsock(struct SockInfo *f)
{
  if(f) {
    if(event_initialized(&f->ev)) {
      event_del(&f->ev);
    }
    free(f);
  }
}

/* Assign information to a SockInfo structure */
static void setsock(struct SockInfo *f, curl_socket_t s, CURL *e, int act,
                    struct GlobalInfo *g)
{
  int kind = ((act & CURL_POLL_IN) ? EV_READ : 0) |
             ((act & CURL_POLL_OUT) ? EV_WRITE : 0) | EV_PERSIST;

  f->sockfd = s;
  f->action = act;
  f->curl = e;
  if(event_initialized(&f->ev)) {
    event_del(&f->ev);
  }
  event_assign(&f->ev, g->evbase, f->sockfd, (short)kind, event_cb, g);
  event_add(&f->ev, NULL);
}

/* Initialize a new SockInfo structure */
static void addsock(curl_socket_t s, CURL *curl, int action,
                    struct GlobalInfo *g)
{
  struct SockInfo *fdp = calloc(1, sizeof(struct SockInfo));

  fdp->global = g;
  setsock(fdp, s, curl, action, g);
  curl_multi_assign(g->multi, s, fdp);
}

/* CURLMOPT_SOCKETFUNCTION */
static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp)
{
  struct GlobalInfo *g = (struct GlobalInfo *)cbp;
  struct SockInfo *fdp = (struct SockInfo *)sockp;
  const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE" };

  fprintf(MSG_OUT, "socket callback: s=%d e=%p what=%s ", s, e, whatstr[what]);
  if(what == CURL_POLL_REMOVE) {
    fprintf(MSG_OUT, "\n");
    remsock(fdp);
  }
  else {
    if(!fdp) {
      fprintf(MSG_OUT, "Adding data: %s\n", whatstr[what]);
      addsock(s, e, what, g);
    }
    else {
      fprintf(MSG_OUT, "Changing action from %s to %s\n",
              whatstr[fdp->action], whatstr[what]);
      setsock(fdp, s, e, what, g);
    }
  }
  return 0;
}

/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(char *ptr, size_t size, size_t nmemb, void *data)
{
  (void)ptr;
  (void)data;
  return size * nmemb;
}

/* CURLOPT_PROGRESSFUNCTION */
static int xferinfo_cb(void *p, curl_off_t dltotal, curl_off_t dlnow,
                       curl_off_t ult, curl_off_t uln)
{
  struct ConnInfo *conn = (struct ConnInfo *)p;
  (void)ult;
  (void)uln;

  fprintf(MSG_OUT, "Progress: %s (%" CURL_FORMAT_CURL_OFF_T "/"
          "%" CURL_FORMAT_CURL_OFF_T ")\n", conn->url, dlnow, dltotal);
  return 0;
}

/* Create a new easy handle, and add it to the global curl_multi */
static void new_conn(const char *url, struct GlobalInfo *g)
{
  struct ConnInfo *conn;
  CURLMcode mresult;

  conn = calloc(1, sizeof(*conn));
  conn->error[0] = '\0';

  conn->curl = curl_easy_init();
  if(!conn->curl) {
    fprintf(MSG_OUT, "curl_easy_init() failed, exiting!\n");
    exit(2);
  }
  conn->global = g;
  conn->url = strdup(url);
  curl_easy_setopt(conn->curl, CURLOPT_URL, conn->url);
  curl_easy_setopt(conn->curl, CURLOPT_WRITEFUNCTION, write_cb);
  curl_easy_setopt(conn->curl, CURLOPT_WRITEDATA, conn);
  curl_easy_setopt(conn->curl, CURLOPT_VERBOSE, 1L);
  curl_easy_setopt(conn->curl, CURLOPT_ERRORBUFFER, conn->error);
  curl_easy_setopt(conn->curl, CURLOPT_PRIVATE, conn);
  curl_easy_setopt(conn->curl, CURLOPT_NOPROGRESS, 0L);
  curl_easy_setopt(conn->curl, CURLOPT_XFERINFOFUNCTION, xferinfo_cb);
  curl_easy_setopt(conn->curl, CURLOPT_PROGRESSDATA, conn);
  curl_easy_setopt(conn->curl, CURLOPT_FOLLOWLOCATION, 1L);
  fprintf(MSG_OUT, "Adding easy %p to multi %p (%s)\n",
          conn->curl, g->multi, url);
  mresult = curl_multi_add_handle(g->multi, conn->curl);
  mcode_or_die("new_conn: curl_multi_add_handle", mresult);

  /* note that the add_handle() sets a time-out to trigger soon so that
     the necessary socket_action() gets called */
}

/* This gets called whenever data is received from the fifo */
static void fifo_cb(int fd, short event, void *arg)
{
  char s[1024];
  long int rv = 0;
  int n = 0;
  struct GlobalInfo *g = (struct GlobalInfo *)arg;
  (void)fd;
  (void)event;

  do {
    s[0] = '\0';
    rv = fscanf(g->input, "%1023s%n", s, &n);
    s[n] = '\0';
    if(n && s[0]) {
      if(!strcmp(s, "stop")) {
        g->stopped = 1;
        if(g->still_running == 0)
          event_base_loopbreak(g->evbase);
      }
      else
        new_conn(s, arg); /* if we read a URL, go get it! */
    }
    else
      break;
  } while(rv != EOF);
}

/* Create a named pipe and tell libevent to monitor it */
static const char *fifo = "hiper.fifo";
static int init_fifo(struct GlobalInfo *g)
{
  struct stat st;
  curl_socket_t sockfd;

  fprintf(MSG_OUT, "Creating named pipe \"%s\"\n", fifo);
  if(lstat(fifo, &st) == 0) {
    if((st.st_mode & S_IFMT) == S_IFREG) {
      errno = EEXIST;
      perror("lstat");
      return 1;
    }
  }
  unlink(fifo);
  if(mkfifo(fifo, 0600) == -1) {
    perror("mkfifo");
    return 1;
  }
  sockfd = open(fifo, O_RDWR | O_NONBLOCK, 0);
  if(sockfd == -1) {
    perror("open");
    return 1;
  }
  g->input = fdopen(sockfd, "r");

  fprintf(MSG_OUT, "Now, pipe some URL's into > %s\n", fifo);
  event_assign(&g->fifo_event, g->evbase, sockfd, EV_READ | EV_PERSIST,
               fifo_cb, g);
  event_add(&g->fifo_event, NULL);
  return 0;
}

static void clean_fifo(struct GlobalInfo *g)
{
  event_del(&g->fifo_event);
  fclose(g->input);
  unlink(fifo);
}

int main(void)
{
  CURLcode result;
  struct GlobalInfo g;

  result = curl_global_init(CURL_GLOBAL_ALL);
  if(result != CURLE_OK)
    return (int)result;

  memset(&g, 0, sizeof(g));
  g.evbase = event_base_new();
  if(init_fifo(&g)) {
    curl_global_cleanup();
    return 1;
  }
  g.multi = curl_multi_init();
  evtimer_assign(&g.timer_event, g.evbase, timer_cb, &g);

  /* setup the generic multi interface options we want */
  curl_multi_setopt(g.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
  curl_multi_setopt(g.multi, CURLMOPT_SOCKETDATA, &g);
  curl_multi_setopt(g.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
  curl_multi_setopt(g.multi, CURLMOPT_TIMERDATA, &g);

  /* we do not call any curl_multi_socket*() function yet as we have no handles
     added! */

  event_base_dispatch(g.evbase);

  /* this, of course, does not get called since the only way to stop this
     program is via ctrl-C, but it is here to show how cleanup /would/ be
     done. */
  clean_fifo(&g);
  event_del(&g.timer_event);
  event_base_free(g.evbase);
  curl_multi_cleanup(g.multi);
  curl_global_cleanup();
  return 0;
}
